package org.jnius;


public enum SimpleEnum {
    GOOD, BAD, UGLY,
}
